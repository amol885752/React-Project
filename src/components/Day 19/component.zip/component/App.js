import logo from './logo.svg';
import './App.css';
import Post from './component/posts/post-main'

function App() {
  return (
    <div className="App">
     <Post/>
    </div>
  );
}

export default App;
