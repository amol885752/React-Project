import React from 'react'

function UserList() {
  return (
    <div className='container'>UserList</div>
  )
}

export default UserList