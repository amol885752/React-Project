import React from 'react'

const AddedUser = () => {
  return (
    <div>AddedUser</div>
  )
}

export default AddedUser