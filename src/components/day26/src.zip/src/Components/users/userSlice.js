import { createSlice } from "@reduxjs/toolkit";

//crate user reducer
const userSlice = createSlice({
    name:'users',
    initialState:{
        users:[]
    },
    reducers:{

        //addd user method

        //delete user

        //update user



    }
})

export default userSlice.reducer