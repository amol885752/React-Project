import axios from 'axios'
import React, { Component } from 'react'

 class UpdatePost extends Component {

    constructor(props) {
      super(props)
    
      this.state = {
        userid:props.updatePostData.userId,
        title:props.updatePostData.title,
        body:props.updatePostData.body
      }
    }
    
    updatePostData =()=>{
        const res = axios(`https://jsonplaceholder.typicode.com/posts/${this.props.updatePostData.id}`, {
            method: 'PUT',
            body: JSON.stringify({
              id: 1,
              title: 'foo',
              body: 'bar',
              userId: 1,
            }),
            headers: {
              'Content-type': 'application/json; charset=UTF-8',
            },
          })
          alert('Post data updated successfully...')
    }
  render() {
   
    return (
      <div>
               {/* {JSON.stringify(this.props.updatePostData)} */}
        <form onSubmit={this.updatePostData}>
          <div>
            <h5>UPDATE  POST</h5>
          </div>
          <div className='mrfBtm'>
            UserID : <input type="text" className='mrgRight' value={this.state.userid} onChange={(e) => this.setState({ userid: e.target.value })} />
            Title : <input type="text" className='mrgRight' value={this.state.title} onChange={(e) => this.setState({ title: e.target.value })} />
            Body : <input type="text" value={this.state.body} onChange={(e) => this.setState({ body: e.target.value })} />
          </div>
          <div className='mrfBtm'>
            <button type="submit">UPDATE POST</button>
          </div>
        </form>
      </div>

    )
  }
}

export default UpdatePost
