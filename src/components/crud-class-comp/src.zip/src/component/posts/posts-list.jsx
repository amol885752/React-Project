import axios from 'axios'
import React, { Component } from 'react'
import './post.css'
import DeletePost from './delete-btn'
import UpdatePost from './update-post'
 class PostsList extends Component {

    constructor(props) {
      super(props)
    
      this.state = {
         posts:[],
         updateFlag:false
      }
    }
    //fetch data using axios 
   async componentDidMount(){
     const res= await axios.get('https://jsonplaceholder.typicode.com/posts')   
     console.log(res)
     if(res.data.length>0){
        this.setState({
            posts:res.data,
            updatePostData:{},
            postUpdateFlag:false
        })
     }
    }

    //update post operation 
    handleUpdate =(post)=>{
      // alert(`User ID :${post.userId} Title :${post.title} Body: ${post.body}`)
      this.setState({
        
        updatePostData:post,
        postUpdateFlag:true,
      })
    }

  render() {
    return (
      <div className='postListTable'>
            {/* <h6>{JSON.stringify(this.state.posts)}</h6> */}

           {this.state.postUpdateFlag ? <UpdatePost updatePostData={this.state.updatePostData}/> :
            <table>
                <thead>
                    <tr>
                        <th>USER ID</th>
                        <th>TITLE</th>
                        <th>BODY</th>
                    </tr>
                </thead>
                <tbody>
                    {
                      this.state.posts.map((post,index)=>{
                        return(
                            <tr key={index}>
                                <td>{post.userId}</td>
                                <td>{post.title}</td>
                                <td>{post.body}</td>
                                <td>{<DeletePost id={post.id}/>}</td>
                               <td><button onClick={()=>this.handleUpdate(post)}>Update</button></td>
                            </tr>
                        )
                      })  
                    }
                </tbody>
            </table>
            }
      </div>
    )
  }
}

export default PostsList 
